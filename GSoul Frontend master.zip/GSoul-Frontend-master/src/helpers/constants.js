import { ethers } from 'ethers';
export const sbt_address = '0xc6b8df9120FA5aAA081ad84Ed695D9844eA526Dd';
export const storage_address = '0xd97c935E85E051E33a5427664E9638839726DB5b';
export const provider = new ethers.providers.Web3Provider(window.ethereum, "any");

